/****************************************************************************
 *
 * Copyright (C) 2009-2010 Menion. All rights reserved.
 *
 * This file is part of the LocA & SmartMaps software.
 *
 * Email menion@asamm.cz for more information.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 ***************************************************************************/
package menion.android.whereyougo;

import menion.android.gui.extension.CustomDialog;
import menion.android.gui.extension.CustomMain;
import menion.android.gui.extension.UtilsGUI;
import menion.android.settings.Settings;
import menion.android.utils.A;
import android.view.View;

/**
 * @author menion
 * @since 1.4.2010 2010
 */
public class MainAfterStart {

//	private static final String TAG = "MainAfterStart";
	
    /****************************************/
    /*         AFTER START ACTIONS          */
    /****************************************/
    
    private static boolean stage01Completed = false;
    
    public static void afterStartAction() {
    	if (!stage01Completed) {
    		int lastVersion = Settings.getApplicationVersionLast();
    		final int actualVersion = Settings.getApplicationVersionActual();
    		if (lastVersion == 0 || actualVersion != lastVersion) {
    			String news = getNews(lastVersion, actualVersion);
    			if (news != null && news.length() > 0) {
    				new CustomDialog.Builder(A.getMain(), false).
    				setTitle(CustomMain.APP_NAME, R.drawable.icon).
    				setContentView(UtilsGUI.getFilledWebView(A.getMain(), news), true).
    				setNeutralButton(R.string.ok, new CustomDialog.OnClickListener() {
						@Override
						public boolean onClick(CustomDialog dialog, View v, int btn) {
    						stage01Completed = true;
    						Settings.setApplicationVersionLast(actualVersion);
							return true;
						}
					}).show();
    			} else {
    				stage01Completed = true;
    			}
    		} else {
    			stage01Completed = true;
    		}
    	}
    }
    
    public static String getNews(int lastVersion, int actualVersion) {
   		String newsInfo = "";
    	
   		if (lastVersion == 0) {
   			newsInfo += "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /></head><body>";
   			newsInfo += CustomMain.loadAssetString(Settings.getLanguageCode() + "_first.html");
           	newsInfo += "</body></html>";
        } else {
        	newsInfo = CustomMain.getNewsFromTo(lastVersion, actualVersion);
        }

   		return newsInfo;
    }
}
