package menion.android.whereyougo;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import menion.android.utils.Logger;
import menion.android.utils.UtilsIO;

import cz.matejcik.openwig.platform.SeekableFile;

public class WSeekableFile implements SeekableFile{

	private static final String TAG = "WSeekableFile";
	
	private RandomAccessFile raf;
	
	public WSeekableFile(File file) {
		try {
			this.raf = new RandomAccessFile(file, "rw");
		} catch (Exception e) {
			Logger.e(TAG, "WSeekableFile(" + file.getAbsolutePath() + ")", e);
		}
	}
	
	public long position() throws IOException {
//Logger.i(TAG, "position(), res:" + raf.getFilePointer());
		return raf.getFilePointer();
	}

	public int read() throws IOException {
		return raf.read();
	}

	public double readDouble() throws IOException {
//		return raf.readDouble();
    	return UtilsIO.readDouble(raf);
	}

	public void readFully(byte[] buf) throws IOException {
		raf.read(buf);
	}

	public int readInt() throws IOException {
//		return raf.readInt();
		return UtilsIO.readInt(raf);
	}

	public long readLong() throws IOException {
//		return raf.readLong();
		return UtilsIO.readLong(raf);
	}

	public short readShort() throws IOException {
//		return raf.readShort();
       	return UtilsIO.readShort(raf);
	}

	public String readString() throws IOException {
        StringBuffer sb = new StringBuffer();
        int b = raf.read();
        while (b > 0) {
            sb.append((char) b);
            b = raf.read();
        }
        return sb.toString();
	}

	public void seek(long pos) throws IOException {
//Logger.i(TAG, "seek(" + pos + ")");
		raf.seek(pos);
	}

	public long skip(long what) throws IOException {
//Logger.i(TAG, "skip(" + what + ")");
		return raf.skipBytes((int) what);
	}

}
