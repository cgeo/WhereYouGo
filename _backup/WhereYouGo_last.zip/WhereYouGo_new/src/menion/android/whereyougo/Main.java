package menion.android.whereyougo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Vector;

import menion.android.geoData.GeoDataExtra;
import menion.android.geoData.GeoDataStyle;
import menion.android.geoData.Waypoint;
import menion.android.gui.extension.CustomDialog;
import menion.android.gui.extension.CustomMain;
import menion.android.gui.extension.DataInfo;
import menion.android.gui.extension.FragmentDialogWorker;
import menion.android.gui.extension.FragmentDialogWorkerHandler;
import menion.android.gui.extension.IconedListAdapter;
import menion.android.gui.extension.UtilsGUI;
import menion.android.gui.extension.FragmentDialogWorker.ProgressAsyncTask;
import menion.android.gui.popup.ActionButton;
import menion.android.gui.popup.PopupAction;
import menion.android.hardware.location.LocationState;
import menion.android.http.UtilsHttp;
import menion.android.maps.MapContent;
import menion.android.maps.mapItems.MapItem;
import menion.android.maps.mapItems.PointMapItem;
import menion.android.settings.Loc;
import menion.android.settings.Settings;
import menion.android.utils.A;
import menion.android.utils.Const;
import menion.android.utils.FileSystem;
import menion.android.utils.FlurryLog;
import menion.android.utils.Images;
import menion.android.utils.Logger;
import menion.android.utils.ManagerNotify;
import menion.android.whereyougo.gui.GpsActivity;
import menion.android.whereyougo.gui.GuideActivity;
import menion.android.whereyougo.gui.MapScreen;
import menion.android.whereyougo.maps.WMapScreenView;
import menion.android.whereyougo.utils.UtilsSettings;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import cz.matejcik.openwig.Engine;
import cz.matejcik.openwig.WherigoLib;
import cz.matejcik.openwig.formats.CartridgeFile;

public class Main extends CustomMain {

	private static final String TAG = "Main";
	
	public static WUI wui = new WUI();
	public static WLocationService wLocationService = new WLocationService();
	public static CartridgeFile cartridgeFile;

	public static String selectedFile;
	
	private static Vector<CartridgeFile> cartridgeFiles;
	
	static {
		// application name
		CustomMain.APP_NAME = "WhereYouGo";
		// create directories during startup
		CustomMain.DIRS = new String[] {
				FileSystem.CACHE,
				FileSystem.CACHE_MAP_FOLDER};
		// set filePath to Maps to Locus App
		FileSystem.ROOT_MAP = "Locus";
	}

	@Override
	public String getFlurryCode() {
		return "H6L4T1F4RRKMRLADMK8Z";
	}

	@Override
	public Date getDateValidTo() {
		return new Date(Long.MAX_VALUE);
	}

	@Override
	protected int getCloseValue() {
		return CLOSE_DESTROY_APP_NO_DIALOG;
	}

	@Override
	protected String getCloseAdditionalText() {
		return null;
	}

	@Override
	protected void eventRegisterOnly() {
	}

	@Override
	protected void eventFirstInit() {
    	// set user-agent
		try {
			HTTP_USER_AGENT = 
				"WhereYouGo/" + getPackageManager().getPackageInfo(getPackageName(), 0).versionName +
				 " (Linux; U; Android; en-us)";
		} catch (Exception e) {
			HTTP_USER_AGENT = 
				"WhereYouGo/unknown (Linux; U; Android; en-us)";
		}
		// now set application as PRO
		Const.STATE_PRO_VERSION = true;
        // register main to A class
        A.registerMapContent(new MapContent());
        // set Wherigo
        WherigoLib.env.put(WherigoLib.DEVICE_ID, HTTP_USER_AGENT);
    }
	
	@Override
	protected void eventSecondInit() {
    	// initialize maps
    	A.getMapContent().setBasics(!Const.STATE_RELEASE);
    	// call after start actions here
        MainAfterStart.afterStartAction();
	}

	
	@Override
	protected void eventCreateLayout() {
		setContentView(R.layout.layout_main);

		// set title
		((TextView) findViewById(R.id.title_text)).setText(APP_NAME);
		
		// define buttons
		View.OnClickListener mOnClickListener = new View.OnClickListener() {
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.button_start:
					showCartridgeList();
					break;
				case R.id.button_map:
					WMapScreenView.removeTempItems(true);
					Intent intent01 = new Intent(Main.this, MapScreen.class);
					startActivity(intent01);
					break;
				case R.id.button_gps:
					Intent intent02 = new Intent(Main.this, GpsActivity.class);
					startActivity(intent02);
					break;
				case R.id.button_settings:
					UtilsSettings.showSettings(Main.this, UtilsSettings.TYPE_ALL);
					break;
				case R.id.button_logo:
					FlurryLog.activityCall(TAG, "button_logo");
					final PopupAction pa = new PopupAction(v, false);
					
					ActionButton itemAboutApp = new ActionButton();
					itemAboutApp.setText(getString(R.string.about_application));
					itemAboutApp.setOnClickListener(new View.OnClickListener() {
						public void onClick(View v) {
							showDialog(DIALOG_ABOUT);
							pa.dismiss();
						}
					});
					pa.addActionView(itemAboutApp);
					
					ActionButton itemNews = new ActionButton();
					itemNews.setText(getString(R.string.news));
					itemNews.setOnClickListener(new View.OnClickListener() {
						public void onClick(View v) {
							showDialog(DIALOG_NEWS);
							pa.dismiss();
						}
					});
					pa.addActionView(itemNews);
					pa.show();
					break;
				}
			}
		};
		
		View.OnLongClickListener mOnLongClickListener = new View.OnLongClickListener() {
			public boolean onLongClick(View v) {
				switch (v.getId()) {
				case R.id.button_start:
					break;
				case R.id.button_map:
					break;
				case R.id.button_gps:
					break;
				case R.id.button_settings:
					break;
				case R.id.button_logo:
					break;
				}
				return true;
			}
		};
		
		UtilsGUI.setButtons(this, new int[] {
				R.id.button_start, R.id.button_map, R.id.button_gps, R.id.button_settings,
				R.id.button_logo}, mOnClickListener, mOnLongClickListener);
	}
	
	private void showCartridgeList() {
		if (cartridgeFiles != null && cartridgeFiles.size() != 0) {
			FragmentDialogWorkerHandler worker = new FragmentDialogWorkerHandler() {
				
				private ArrayList<DataInfo> data;
				
				@Override
				public void doInBackground(ProgressAsyncTask task) {
					data = new ArrayList<DataInfo>();
					try {
						// sort cartridges
						final Location actLoc = LocationState.getLocation();
						final Location loc1 = new Location(TAG);
						final Location loc2 = new Location(TAG);
						Collections.sort(cartridgeFiles, new Comparator<CartridgeFile>() {
							public int compare(
									CartridgeFile object1,
									CartridgeFile object2) {
								loc1.setLatitude(object1.latitude);
								loc1.setLongitude(object1.longitude);
								loc2.setLatitude(object2.latitude);
								loc2.setLongitude(object2.longitude);
								return (int) (actLoc.distanceTo(loc1) - actLoc.distanceTo(loc2));
							}
						});
						
						for (int i = 0; i < cartridgeFiles.size(); i++) {
							CartridgeFile file = cartridgeFiles.get(i);
							byte[] iconData = file.getFile(file.iconId);
							Bitmap icon;
							try {
								icon = BitmapFactory.decodeByteArray(iconData, 0, iconData.length);
							} catch (Exception e) {
								icon = Images.getImageB(R.drawable.icon_gc_wherigo);
							}
							
							DataInfo di = new DataInfo(file.name, UtilsHttp.repairHtmlFile(file.type +
									", " + file.author + ", " + file.version), icon);
							di.value01 = file.latitude;
							di.value02 = file.longitude;
							di.setDistAzi(actLoc);
							data.add(di);
						}
					} catch (Exception e) {
						Logger.e(TAG, "button_start_click", e);
					}
				}

				@Override
				public void onPostExecute() {
					IconedListAdapter adapter = new IconedListAdapter(A.getMain(), data, null);
					adapter.setTextView02Visible(View.VISIBLE, false);
					
					new CustomDialog.Builder(Main.this, true).
					setTitle(R.string.choose_cartridge).
					setTitleExtraCancel().
					setAdapter(UtilsGUI.createListView(Main.this, false, data), new CustomDialog.OnItemClickListener() {
						@Override
						public boolean onClick(CustomDialog dialog, View view, int position, boolean left) {
							try {
								Main.cartridgeFile = cartridgeFiles.get(position);
								Main.selectedFile = Main.cartridgeFile.filename;
							
								if (Main.cartridgeFile.getSavegame().exists()) {
									UtilsGUI.showDialogQuestion(Main.this,
											R.string.resume_previous_cartridge,
											new CustomDialog.OnClickListener() {
												@Override
												public boolean onClick(CustomDialog dialog, View v, int btn) {
													File file = new File(selectedFile.substring(0, selectedFile.length() - 3) + "gwl");
													FileOutputStream fos = null;
													try {
														if (!file.exists())
															file.createNewFile();
														fos = new FileOutputStream(file);
													} catch (Exception e) {
														Logger.e(TAG, "onResume() - create empty saveGame file", e);
													}
													Main.restoreCartridge(fos);
													return true;
												}
											}, new CustomDialog.OnClickListener() {
												@Override
												public boolean onClick(CustomDialog dialog, View v, int btn) {
													Main.wui.showScreen(WUI.SCREEN_CART_DETAIL, null);
													try {
														Main.getSaveFile().delete();
													} catch (Exception e) {
														Logger.e(TAG, "onCreate() - deleteSyncFile", e);
													}
													return true;
												}
											});
								} else {
									Main.wui.showScreen(WUI.SCREEN_CART_DETAIL, null);
								}
							} catch (Exception e) {
								Logger.e(TAG, "onCreate()", e);
							}
							return true;
						}

						@Override
						public boolean onClickLong(CustomDialog dialog, View v, int position, boolean left) {
							return false;
						}
					}).show();
				}
			};

			new FragmentDialogWorker(Main.this, getString(R.string.loading), worker);
		} else {
			UtilsGUI.showDialogInfo(Main.this, 
					getString(R.string.no_wherigo_cartridge_available,
							FileSystem.ROOT, CustomMain.APP_NAME));
		}
	}
	
	@Override
	protected void eventDestroyApp() {
	}
	
    public void onResume() {
    	super.onResume();
    	refreshCartridge();
    }
    
	private static final int DIALOG_ABOUT = 0;
	private static final int DIALOG_NEWS = 1;
	
	protected Dialog onCreateDialog(int id) {
	    final Dialog dialog;
	    switch(id) {
	    case DIALOG_ABOUT:
			StringBuffer buffer = new StringBuffer();
			buffer.append("<div align=\"center\"><h2><b>WhereYouGo</b></h2></div>");
			buffer.append("<div>");
			buffer.append("<b>Wherigo player for Android device</b><br /><br />");
			try {
				buffer.append(Loc.get(R.string.version) + "<br />&nbsp;&nbsp;<b>" + 
						getPackageManager().getPackageInfo(getPackageName(), 0).versionName + "</b><br /><br />");
			} catch (Exception e) {}
			buffer.append(getString(R.string.author) + "<br />&nbsp;&nbsp;<b>Menion Asamm</b><br /><br />");
			buffer.append(getString(R.string.web_page) + "<br />&nbsp;&nbsp;<b><a href=\"http://forum.asamm.cz\">http://forum.asamm.cz</a></b><br /><br />");
			buffer.append(getString(R.string.libraries));
			buffer.append("<br />&nbsp;&nbsp;<b>OpenWig</b>");
			buffer.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;Matejicek");
			buffer.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;<small>http://code.google.com/p/openwig</small>");
			buffer.append("<br />&nbsp;&nbsp;<b>Kahlua</b>");
			buffer.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;Kristofer Karlsson");
			buffer.append("<br />&nbsp;&nbsp;&nbsp;&nbsp;<small>http://code.google.com/p/kahlua/</small>");
			buffer.append("</div>");
			
	    	dialog = new CustomDialog.Builder(this, true).
	    	setTitle(R.string.about_application, R.drawable.ic_title_logo).
	    	setTitleExtraCancel().
	    	setContentView(
	    			UtilsGUI.createContainer(this,
	    			UtilsGUI.getFilledWebView(this, buffer.toString())), true).
	    	setNeutralButtonCancel(R.string.close).
	    	create();
	        break;
	    case DIALOG_NEWS:
	    	dialog = new CustomDialog.Builder(this, true).
	    	setTitle(R.string.news, R.drawable.ic_title_logo).
	    	setTitleExtraCancel().
			setContentView(
					UtilsGUI.createContainer(this,
					UtilsGUI.getFilledWebView(A.getMain(),
					MainAfterStart.getNews(1, Settings.getApplicationVersionActual()))), true).
			setNeutralButtonCancel(R.string.ok).
			create();
	    	break;
	    default:
	        dialog = null;
	    }
	    
	    if (dialog != null) {
	    	dialog.setCanceledOnTouchOutside(true);
	    }
	    
	    return dialog;
	}
    
    
	public static void loadCartridge(OutputStream log) {
		try {
			WUI.startProgressDialog();
			Engine.newInstance(cartridgeFile, log, wui, wLocationService).start();
		} catch (Throwable t) {}
	}

	public static void restoreCartridge(OutputStream log) {
		try {
			WUI.startProgressDialog();
			Engine.newInstance(cartridgeFile, log, wui, wLocationService).restore();
		} catch (Throwable t) {}
	}
	
	public static File getSaveFile() throws IOException {
		try {
			File file = new File(selectedFile.substring(0, selectedFile.length() - 3) + "ows");
			return file;
		} catch (SecurityException e) {
			Logger.e(TAG, "getSyncFile()", e);
			return null;
		}
	}
	
	public static void setBitmapToImageView(Bitmap i, ImageView iv) {
Logger.w(TAG, "setBitmapToImageView(), " + i.getWidth() + " x " + i.getHeight());
		float width = i.getWidth() - 10;
		float height = (Const.SCREEN_WIDTH / width) * i.getHeight();
	
		if ((height / Const.SCREEN_HEIGHT) > 0.60f) {
			height = 0.60f * Const.SCREEN_HEIGHT;
			width = (height / i.getHeight()) * i.getWidth();
		}
		iv.setMinimumWidth((int) width);
		iv.setMinimumHeight((int) height);
		iv.setImageBitmap(i);
	}

	private void refreshCartridge() {
Logger.w(TAG, "refreshCartridge(), " + (Main.selectedFile == null));
		if (Main.selectedFile != null)
			return;
		
        // load cartridge files
		File[] files = FileSystem.getFiles(FileSystem.ROOT, "gwc");
		cartridgeFiles = new Vector<CartridgeFile>();
        
        // add cartridges to map
		ArrayList<Waypoint> wpts = new ArrayList<Waypoint>();
		// style for map items
        GeoDataStyle styleNormal = new GeoDataStyle(Images.getImageB(R.drawable.icon_gc_wherigo), 1.0f);
        GeoDataStyle styleHighlight = new GeoDataStyle(Images.getImageB(R.drawable.icon_gc_wherigo), 1.25f);
        
        File actualFile = null;
       	if (files != null) {
       		for (File file : files) {
       	        try {
        			actualFile = file;
        			CartridgeFile cart = CartridgeFile.read(new WSeekableFile(file), new WSaveFile(file));
        			if (cart != null) {
        				cart.filename = file.getAbsolutePath();
        				
        				Waypoint waypoint = new Waypoint(cart.name);
        				waypoint.addParameter(cart.description, GeoDataExtra.PAR_DESCRIPTION);
        				waypoint.styleNormal = styleNormal;
        				waypoint.styleHighlight = styleHighlight;
        				
        				Location loc = new Location(TAG);
        				loc.setLatitude(cart.latitude);
        				loc.setLongitude(cart.longitude);
        				waypoint.setLocation(loc, true);
        				
        				cartridgeFiles.add(cart);
        				wpts.add(waypoint);
        			}
       	        } catch (Exception e) {
       	        	Logger.w(TAG, "refreshCartridge(), file:" + actualFile + ", e:" + e.toString());
       	        	ManagerNotify.toastShortMessage(Loc.get(R.string.invalid_cartridge, file.getName()));
       	        }
       	    }
       	}

       	if (wpts.size() > 0) {
    		PointMapItem pmi = new PointMapItem(Images.getImageB(R.drawable.icon_gc_wherigo));
    		pmi.addWaypoints(wpts);
    		A.getMapItemManager().addItem(MapItem.PRIORITY_5, "Cartridges", pmi);
    	} else {
    		A.getMapItemManager().removeItem("Cartridges");
    	}
	}
	
	/**
	 * Call activity that guide onto point.
	 * @param activity
	 * @return true if internal activity was called. False if external by intent.
	 */
	public static boolean callGudingScreen(Activity activity) {
		Intent intent = new Intent(activity, GuideActivity.class);
		activity.startActivity(intent);
		return true;
	}
}