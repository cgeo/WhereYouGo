package menion.android.whereyougo.utils;

import menion.android.whereyougo.gui.SettingScreens;
import android.app.Activity;
import android.content.Intent;

public class UtilsSettings extends menion.android.settings.UtilsSettings {

	public static void showSettings(Activity activity, int type) {
		Intent intentGui = new Intent(activity, SettingScreens.class);
		intentGui.putExtra("type", type);
		activity.startActivity(intentGui);			
	}
}
