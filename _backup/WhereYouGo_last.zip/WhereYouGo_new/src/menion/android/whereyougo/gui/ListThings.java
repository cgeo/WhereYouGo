package menion.android.whereyougo.gui;

import java.util.Vector;

import cz.matejcik.openwig.Engine;
import cz.matejcik.openwig.Thing;

import menion.android.whereyougo.Main;
import menion.android.whereyougo.WUI;
import se.krka.kahlua.vm.LuaTable;
import android.os.Bundle;

public class ListThings extends ListVarious {

	public static final int INVENTORY = 0;
	public static final int SURROUNDINGS = 1;
	private int mode;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mode = getIntent().getIntExtra("mode", INVENTORY);
	}
	
	@Override
	protected void callStuff(Object what) {
		Thing t = (Thing) what;
		if (t.hasEvent("OnClick")) {
			Engine.callEvent(t, "OnClick", null);
		} else {
			Main.wui.showScreen(WUI.DETAILSCREEN, t);
		}
		ListThings.this.finish();
	}

	@Override
	protected String getStuffName(Object what) {
		return ((Thing) what).name;
	}

	@Override
	protected Vector<Object> getValidStuff() {
		LuaTable container;
		if (mode == INVENTORY)
			container = Engine.instance.player.inventory;
		else
			container = Engine.instance.cartridge.currentThings();
		
		Vector<Object> newthings = new Vector<Object>();
		Object key = null;
		while ((key = container.next(key)) != null) {
			Thing t = (Thing) container.rawget(key);
			if (t.isVisible())
				newthings.add(t);
		}
		return newthings;
	}

	@Override
	protected boolean stillValid() {
		return true;
	}
	
	// TODO in TAB version
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
//			return getParent().onKeyDown(keyCode, event);
//		} else {
//			return super.onKeyDown(keyCode, event);
//		}
//	}
}
