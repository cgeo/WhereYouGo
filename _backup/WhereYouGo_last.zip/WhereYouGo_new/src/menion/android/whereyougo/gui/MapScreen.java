package menion.android.whereyougo.gui;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Vector;

import menion.android.gui.extension.CustomActivity;
import menion.android.gui.extension.CustomDialog;
import menion.android.gui.extension.DataInfo;
import menion.android.gui.extension.UtilsGUI;
import menion.android.gui.popup.PopupAction;
import menion.android.hardware.location.LocationState;
import menion.android.maps.MapContentZoom;
import menion.android.maps.MapScreenInterface;
import menion.android.maps.MapScreenViewSettings;
import menion.android.maps.filemaps.FileMapManager;
import menion.android.maps.filemaps.FileMapTypeAbstract;
import menion.android.maps.filemaps.FileMapTypeVector;
import menion.android.maps.filemaps.StoreManagerMapInfo;
import menion.android.maps.filemaps.UtilsFileMaps;
import menion.android.maps.online.OnlineManager;
import menion.android.maps.online.OnlineProvider;
import menion.android.settings.SettingValues;
import menion.android.settings.Settings;
import menion.android.utils.A;
import menion.android.utils.FlurryLog;
import menion.android.utils.ManagerNotify;
import menion.android.utils.Utils;
import menion.android.whereyougo.R;
import menion.android.whereyougo.maps.WMapScreenView;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ToggleButton;
import cz.matejcik.openwig.Engine;
import cz.matejcik.openwig.Zone;

public class MapScreen extends CustomActivity implements Refreshable, MapScreenInterface {

	private static final String TAG = "MapScreen";
	
	private static final int MENU_ONLINE_MAPS = 0;
	private static final int MENU_OFFLINE_MAPS = 1;
	private static final int MENU_VECTOR_MAPS = 2;
	
	private WMapScreenView mapScreen;
	
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
    	// handle event
        int action = event.getAction();
        int keyCode = event.getKeyCode();
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
        	if (SettingValues.GLOBAL_USE_HW_BUTTONS) {
            	if (action == KeyEvent.ACTION_UP) {
            		A.getMapContent().zoomIn();
            	}
                return true;	
            } else {
            	return super.dispatchKeyEvent(event);
            }
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (SettingValues.GLOBAL_USE_HW_BUTTONS) {
            	if (action == KeyEvent.ACTION_UP) {
            		A.getMapContent().zoomOut();
                }
                return true;	
            } else {
            	return super.dispatchKeyEvent(event);
            }
        } else if (mapScreen.onKeyUp(keyCode, event)) {
            return true;
        } else {
        	return super.dispatchKeyEvent(event);
        }
    }
    
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_map);
	
		// get map view
		mapScreen = (WMapScreenView) findViewById(R.id.wmapscreenview_map);
		// define buttons
		View.OnClickListener mOnClickListener = new View.OnClickListener() {
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.btn_centre:
					FlurryLog.activityCall(TAG, "btn_centre");
					boolean checked = ((ToggleButton) v).isChecked();
					if (!checked) {
						A.getMapContent().disableCentering();
					} else {
						if (LocationState.isActuallyHardwareGpsOn()) {
							A.getMapContent().centerMap(LocationState.getLocation(), false);
							A.getMapContent().enableCentering();
						} else {
							A.getMapContent().centerMap(
									LocationState.getLastKnownLocation(), false);
							((ToggleButton) findViewById(R.id.btn_centre)).setChecked(false);
						}
					}
					A.getMapContent().repaint();
					break;
				case R.id.btn_lock:
					FlurryLog.activityCall(TAG, "btn_lock");
					if (((ToggleButton) v).isChecked() && !MapContentZoom.isPinchZoomActive()) {
						MapContentZoom.lockZoom(true);
					} else {
						MapContentZoom.lockZoom(false);
					}
					A.getMapContent().repaint();
					break;
				case R.id.btn_rotate:
					FlurryLog.activityCall(TAG, "btn_rotate");
					if (MapScreenViewSettings.isCanvasRotateByHandEnabled()) {
						mapScreen.enableRotateByHand(false);
						if (MapScreenViewSettings.isCanvasRotateEnabled() ||
								MapScreenViewSettings.isPositionOrientationEnabled()) {
							((ToggleButton) findViewById(R.id.btn_rotate)).setChecked(true);
						}
					} else {
						if (MapScreenViewSettings.isCanvasRotateEnabled()) {
							mapScreen.enableScreenRotate(false);
							return;
						}
						if (MapScreenViewSettings.isPositionOrientationEnabled()) {
							mapScreen.enablePositionOrientation(false);
							return;
						}
						
						switch (SettingValues.MAP_ROTATE_BUTTON_TYPE) {
						case Settings.VALUE_MAP_ROTATE_BUTTON_TYPE_CHOOSE_DIALOG:
							((ToggleButton) findViewById(R.id.btn_rotate)).setChecked(false);
							PopupAction action = new PopupAction(v, false);
							UtilsGUI.addActionItem(action,
									getString(R.string.rotate_map), R.drawable.ic_rotate_screen_default,
									new View.OnClickListener() {
										@Override
										public void onClick(View v2) {
											((ToggleButton) findViewById(R.id.btn_rotate)).setChecked(true);
											mapScreen.enableScreenRotate(true);	
										}
									});
							UtilsGUI.addActionItem(action,
									getString(R.string.show_view), R.drawable.ic_rotate_view_default,
									new View.OnClickListener() {
										@Override
										public void onClick(View v2) {
											((ToggleButton) findViewById(R.id.btn_rotate)).setChecked(true);
											mapScreen.enablePositionOrientation(true);	
										}
									});
							action.show();
							break;
						case Settings.VALUE_MAP_ROTATE_BUTTON_TYPE_ROTATE_MAP:
							mapScreen.enableScreenRotate(true);
							break;
						case Settings.VALUE_MAP_ROTATE_BUTTON_TYPE_SHOW_VIEW:
							mapScreen.enablePositionOrientation(true);
							break;
						}
					}
					break;
				case R.id.btn_zoom_in:
					FlurryLog.activityCall(TAG, "btn_zoom_in");
					A.getMapContent().zoomIn();
					break;
				case R.id.btn_zoom_out:
					FlurryLog.activityCall(TAG, "btn_zoom_out");
					A.getMapContent().zoomOut();
					break;
				}
			}
		};
		
		View.OnLongClickListener mOnLongClickListener = new View.OnLongClickListener() {
			public boolean onLongClick(View v) {
				switch (v.getId()) {
				case R.id.btn_centre:
					FlurryLog.activityCall(TAG, "btn_centre" + FlurryLog.BUTTON_CLICK_LONG_SUFFIX);
					break;
				case R.id.btn_lock:
					FlurryLog.activityCall(TAG, "btn_lock" + FlurryLog.BUTTON_CLICK_LONG_SUFFIX);
					break;
				case R.id.btn_rotate:
					FlurryLog.activityCall(TAG, "btn_rotate" + FlurryLog.BUTTON_CLICK_LONG_SUFFIX);
					break;
				case R.id.btn_zoom_in:
					FlurryLog.activityCall(TAG, "btn_zoom_in" + FlurryLog.BUTTON_CLICK_LONG_SUFFIX);
					break;
				case R.id.btn_zoom_out:
					FlurryLog.activityCall(TAG, "btn_zoom_out" + FlurryLog.BUTTON_CLICK_LONG_SUFFIX);
					break;
				}
				return true;
			}
		};
		
		UtilsGUI.setButtons(this, new int[] {
				R.id.btn_centre, R.id.btn_rotate, R.id.btn_lock, R.id.btn_zoom_in, R.id.btn_zoom_out},
				mOnClickListener, mOnLongClickListener);

		A.getMapItemManager().disableInitializeState();
	}
	
	public void onResume() {
		super.onResume();
		if (A.getMapContent() != null) { // correct init
	        A.getMapContent().onResume(mapScreen, this);
	        
	        if (MapScreenViewSettings.isCanvasRotateEnabled() || 
	        		MapScreenViewSettings.isPositionOrientationEnabled()) {
	        	((ToggleButton) findViewById(R.id.btn_rotate)).setChecked(true);
	        }
		}
		refresh();
	}
	
    public void onStart() {
    	super.onStart();
    	if (A.getMapContent() != null)
    		A.getMapContent().onStart();
    }
	
	public void onStop() {
		super.onStop();
		if (A.getMapContent() != null)
			A.getMapContent().onStop(mapScreen);
	}
	
	public void onDestroy() {
		super.onDestroy();
		if (A.getMapContent() != null)
			A.getMapContent().onDestroy(mapScreen);
	}

	public void refresh() {
		WMapScreenView.removeTempItems(false);
		
		if (Engine.instance != null && Engine.instance.cartridge != null) {
			// add all visible zones
			if (Engine.instance.cartridge.visibleZones() > 0) {
				Vector<Zone> ret = new Vector<Zone>();
				@SuppressWarnings("unchecked")
				Vector<Zone> zones = Engine.instance.cartridge.zones;
				for (int i = 0; i < zones.size(); i++) {
					if (zones.get(i).isVisible())
						ret.add(zones.get(i));
				}
			
				for (int i = 0; i < ret.size(); i++) {
					WMapScreenView.addZone((Zone) ret.get(i));
				}
			}
		}
		A.getMapContent().repaint();
	}

	@Override
	public void disableZoomButtons(boolean disableZoomIn, boolean disableZoomOut) {
		((ImageButton) findViewById(R.id.btn_zoom_in)).setEnabled(!disableZoomIn);
		((ImageButton) findViewById(R.id.btn_zoom_out)).setEnabled(!disableZoomOut);
	}

	@Override
	public void rotateByHandChanged(boolean enable) {
		ToggleButton tb = (ToggleButton) findViewById(R.id.btn_rotate);
		int pL = tb.getPaddingLeft();
		int pR = tb.getPaddingRight();
		int pT = tb.getPaddingTop();
		int pB = tb.getPaddingBottom();
		
		if (enable) {
			if (!tb.isChecked())
				tb.setChecked(true);
			tb.setBackgroundResource(R.drawable.selector_toggle_button_v2);
		} else {
			tb.setBackgroundResource(R.drawable.item_background_holo_light);
		}

		tb.setPadding(pL, pT, pR, pB);
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(Menu.NONE, MENU_ONLINE_MAPS, MENU_ONLINE_MAPS, R.string.online);
		menu.findItem(MENU_ONLINE_MAPS).setIcon(android.R.drawable.ic_menu_mapmode);
		menu.add(Menu.NONE, MENU_OFFLINE_MAPS, MENU_OFFLINE_MAPS, R.string.offline);
		menu.findItem(MENU_OFFLINE_MAPS).setIcon(android.R.drawable.ic_menu_mapmode);
		menu.add(Menu.NONE, MENU_VECTOR_MAPS, MENU_VECTOR_MAPS, R.string.vector);
		menu.findItem(MENU_VECTOR_MAPS).setIcon(android.R.drawable.ic_menu_mapmode);
	    return true;
	}
	
	public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	    case MENU_ONLINE_MAPS:
	    	final ArrayList<DataInfo> data = new ArrayList<DataInfo>();
	    	Enumeration<OnlineProvider> provs = A.getOnlineManager().getProviders();
	    	while (provs.hasMoreElements()) {
	    		OnlineProvider prov = provs.nextElement();
	    		// remove invisible maps
	    		if (!prov.isVisible())
	    			continue;
	    		// remove unwanted providers
	    		if (OnlineManager.isShocart(prov))
	    			continue;
	    		// add map to list
	    		String mapName = prov.getProvider() + " (" + prov.getMode() + ")";
	        	String description = getString(R.string.zooms) + ": " + 
	        	(prov.getMaximumZoomLevel() - prov.getMinimumZoomLevel());
	        	DataInfo di = new DataInfo(mapName, description);
	        	di.addData01 = String.valueOf(prov.getId());
	       		data.add(di);
	    	}
	    	
	    	// sort data
	    	Collections.sort(data, new Comparator<DataInfo>() {
				@Override
				public int compare(DataInfo lhs, DataInfo rhs) {
					return Utils.parseInt(lhs.addData01) - Utils.parseInt(rhs.addData01);
				}
			});
	        
	    	new CustomDialog.Builder(MapScreen.this, true).
	    	setTitle(R.string.online).
	    	setTitleExtraCancel().
	    	setAdapter(UtilsGUI.createListView(MapScreen.this, false, data), new CustomDialog.OnItemClickListener() {
				@Override
				public boolean onClick(CustomDialog dialog, View view, int position, boolean left) {
					A.getMapContent().setOnlineMap(Utils.parseInt(data.get(position).addData01));
					A.getMapContent().repaint();
					return true;
				}

				@Override
				public boolean onClickLong(CustomDialog dialog, View v,
						int position, boolean left) {
					// TODO Auto-generated method stub
					return false;
				}
			}).show();
	    	return true;
	    case MENU_OFFLINE_MAPS:
	    	ArrayList<StoreManagerMapInfo> dataAll = FileMapManager.getMapsAroundScreen(Double.POSITIVE_INFINITY,
					Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, -1);
	    	if (dataAll.size() == 0) {
	    		ManagerNotify.toastLongMessage(R.string.no_offline_maps);
	    		return true;
	    	}
	    	
			final ArrayList<DataInfo> mapDataOff = new ArrayList<DataInfo>();
			prepareMapList(mapDataOff, dataAll);
			
			// set list view
			ListView lv = UtilsGUI.createListView(MapScreen.this, false, mapDataOff);
			
			// now set and show dialog
	    	final CustomDialog dialog = new CustomDialog.Builder(MapScreen.this, true).
	    	setTitle(R.string.offline).
	    	setTitleExtraCancel().
	    	setAdapter(lv).create();
	    	
	    	// set LV listener
			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					UtilsFileMaps.showMap(MapScreen.this, 
							(String) mapDataOff.get(position).addData01,
							UtilsFileMaps.ACTION_CLASSIC, false);
					dialog.dismiss();
				}
			});
			
			// finally show
			dialog.show();
	    	return true;
	    case MENU_VECTOR_MAPS:
	    	ArrayList<FileMapTypeVector> maps = FileMapManager.getVectorMaps();
			if (maps.size() == 0) {
	    		ManagerNotify.toastLongMessage(R.string.no_vector_maps);
	    		return true;
	    	}
			
			final ArrayList<DataInfo> mapDataVec = new ArrayList<DataInfo>();
			for (FileMapTypeVector map : maps) {
				mapDataVec.add(new DataInfo(map.name, null).
						setAddData01(map.mFile.getAbsolutePath()));
			}
				
			// set list view
			ListView lvVec = UtilsGUI.createListView(MapScreen.this, false, mapDataVec);
			
			// now set and show dialog
	    	final CustomDialog dialogVec = new CustomDialog.Builder(MapScreen.this, true).
	    	setTitle(R.string.vector).
	    	setTitleExtraCancel().
	    	setAdapter(lvVec).create();

	    	// set LV listener
	    	lvVec.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					A.getMapContent().setVectorMap((String) mapDataVec.get(position).addData01,
							A.getMapContent().getCenter());
					dialogVec.dismiss();
				}
			});
			
			// finally show
	    	dialogVec.show();
	    	return true;
	    }
	    return false;
	}
	
	@Override
	public void onLocationChanged() {}

	@Override
	public void onMapChanged() {
	}

	@Override
	public void noMapOnScreen(boolean noMap) {
	}

	@Override
	public void centeringChanged(final boolean enable) {
		if (isFinishing())
			return;

		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				((ToggleButton) findViewById(R.id.btn_centre)).setChecked(enable);		
			}
		});
	}
	
	//////////// LOCUS COPY /////////////

	// function copied from locus
	private void prepareMapList(ArrayList<DataInfo> allData, ArrayList<StoreManagerMapInfo> data) {
		ArrayList<DataInfo> maps = new ArrayList<DataInfo>();
		
		for (int i = data.size() - 1; i >= 0; i--) {
			StoreManagerMapInfo smmi = data.get(i);
			
			// get valid mapName
			String mapName = createMapName(smmi, false);
			
			// get already existed DataInfo
			DataInfo actualDi = null;
			for (int j = 0; j < maps.size(); j++) {
				if (maps.get(j).getName().equals(mapName)) {
					actualDi = maps.get(j);
					break;
				}
			}
			if (actualDi == null) {
				actualDi = new DataInfo(mapName);
				actualDi.addData01 = smmi.getFilePath();
				maps.add(actualDi);
			} else {
				data.remove(i);
			}
			
			// set description
			boolean isSqlMap = FileMapManager.getMapType(new File(smmi.getFilePath())) ==
					FileMapTypeAbstract.MAP_TYPE_SQL;
			
			String desc = actualDi.getDescription();
			if (desc.length() == 0) {
				desc = getString(R.string.zooms) + ": " + 
						(isSqlMap ? (smmi.getZoomValue() - 8) : smmi.getZoomValue());
			} else { 
				desc += ", " + (isSqlMap ? (smmi.getZoomValue() - 8) : smmi.getZoomValue());
			}
			actualDi.setDescription(desc);
		}
		
//		// get correct icons
//		for (int i = 0; i < maps.size(); i++) {
//			DataInfo actualDi = maps.get(i);
//			
//			File file = new File((String) actualDi.addData01);
//			actualDi.setImage(R.drawable.var_empty_48);
//			
//			if (!file.exists()) {
//				continue;
//			}
//
//			actualDi.setImage(getImage(file));
//		}
		
		for (DataInfo di : maps) {
			di.setName(di.getName().replace(".sqlitedb", ""));
			allData.add(di);
		}
		
		// now sort data by name
		Collections.sort(allData, new Comparator<DataInfo>() {
			@Override
			public int compare(DataInfo object1, DataInfo object2) {
				return object1.getName().compareTo(object2.getName());
			}
		});
	}
	
	public static String createMapName(StoreManagerMapInfo smmi, boolean clearEnd) {
		// get valid mapName
		String mapName = smmi.getMapName();
		if (mapName.contains("/")
				&& mapName.lastIndexOf("/") < mapName.length() + 1) {
			mapName = mapName.substring(mapName.lastIndexOf("/") + 1);
		}
		
		if (clearEnd) {
			mapName = mapName.replace(".sqlitedb", "");
		}
		return mapName;
	}

	@Override
	public void onMapDraw() {}
}
