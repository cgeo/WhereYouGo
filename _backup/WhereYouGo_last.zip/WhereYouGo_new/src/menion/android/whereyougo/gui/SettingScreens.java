package menion.android.whereyougo.gui;

import static menion.android.settings.UtilsSettings.TYPE_ALL;
import menion.android.R;
import menion.android.gui.extension.CustomPreferenceActivity;
import menion.android.settings.SettingItems;
import menion.android.utils.Logger;
import menion.android.whereyougo.utils.UtilsSettings;
import android.os.Bundle;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;

public class SettingScreens extends CustomPreferenceActivity {

	private static String TAG = "SettingScreens";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle(R.string.settings);
		
		try {
			setPreferenceScreen(createPreferences(SettingScreens.this,
					getIntent().getIntExtra("type", TYPE_ALL)));
			UtilsSettings.setDependecies(this);
		} catch (Exception e) {
			Logger.e(TAG, "onCreate()", e);
		}
	}
	
	public static PreferenceScreen createPreferences(CustomPreferenceActivity activity, int type) {
		if (type == TYPE_ALL) {
			PreferenceScreen root = activity.getPreferenceManager().createPreferenceScreen(activity);
			root.addPreference(createPrefGlobal(activity, activity.getPreferenceManager()));
			root.addPreference(createPrefMap(activity, activity.getPreferenceManager()));
			root.addPreference(createPrefGps(activity, activity.getPreferenceManager()));
			root.addPreference(createPrefSensors(activity, activity.getPreferenceManager()));
			root.addPreference(createPrefGuiding(activity, activity.getPreferenceManager()));
			root.addPreference(createPrefLocale(activity, activity.getPreferenceManager()));
	        return root;
		}
		return null;
	}
	
	public static PreferenceScreen createPrefGlobal(final CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceScreen = prefManager.createPreferenceScreen(activity);
		preferenceScreen.setTitle(R.string.pref_global);
		PreferenceCategory prefCatGlobal = 
			addNewPreferenceCategory(activity, R.string.pref_global, preferenceScreen);
		PreferenceCategory prefCatMapScreen = 
			addNewPreferenceCategory(activity, R.string.pref_map_screen, preferenceScreen);

        SettingItems.addPrefFullscreen(activity, prefCatGlobal);
        SettingItems.addPrefHighlight(activity, prefCatGlobal);

        SettingItems.addPrefGlobalUseHwButtons(activity, prefCatMapScreen);
		SettingItems.addPrefMapSimpleMultiTouch(activity, prefCatMapScreen);
		SettingItems.addPrefMapRotateButton(activity, prefCatMapScreen);
		SettingItems.addPrefMapRememberZoomLock(activity, prefCatMapScreen);
		SettingItems.addPrefMapHoldCenterMethod(activity, prefCatMapScreen);
		
        return init(preferenceScreen);
	}
	
	public static PreferenceScreen createPrefMap(final CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceMap = prefManager.createPreferenceScreen(activity);
		preferenceMap.setTitle(R.string.map);
		PreferenceCategory prefCatMapObjects = 
			addNewPreferenceCategory(activity, R.string.map_objects, preferenceMap);
		PreferenceCategory prefCatMapStyle = 
			addNewPreferenceCategory(activity, R.string.pref_style_on_map, preferenceMap);
		PreferenceCategory prefCatMapAdvanced = 
			addNewPreferenceCategory(activity, R.string.pref_advanced_settings, preferenceMap);
		
        SettingItems.addPrefMapShowCenterCross(activity, prefCatMapObjects);
        SettingItems.addPrefMapShowAccuracyCircle(activity, prefCatMapObjects);
        
//		SettingItems.addPrefMapItemShowLabel(activity, prefCatMapStyle);
		SettingItems.addPrefMapItemColor(activity, prefCatMapStyle);
		SettingItems.addPrefMapItemFontSize(activity, prefCatMapStyle);
		
		SettingItems.addPrefMapOfflineMode(activity, prefCatMapAdvanced);
		SettingItems.addPrefMapCacheToDatabase(activity, prefCatMapAdvanced);
		SettingItems.addPrefMapDoubleSized(activity, prefCatMapAdvanced);
		SettingItems.addPrefMapNightMode(activity, prefCatMapAdvanced);
		
        return init(preferenceMap);
	}
	
	public static PreferenceScreen createPrefGps(CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceGps = prefManager.createPreferenceScreen(activity);
		preferenceGps.setTitle(R.string.gps_and_location);
		// category global
        PreferenceCategory prefCatGlobal = 
        	addNewPreferenceCategory(activity, R.string.pref_global, preferenceGps);
        PreferenceCategory prefCatDisable = 
            	addNewPreferenceCategory(activity, R.string.disable_location, preferenceGps);
		// category bluetooth
		PreferenceCategory prefCatBluetooth = 
			addNewPreferenceCategory(activity, R.string.pref_gps_bluetooth, preferenceGps);
		SettingItems.addPrefGpsBluetooth(activity, prefCatBluetooth);
		SettingItems.addPrefGpsBluetoothClear(activity, prefManager, prefCatBluetooth);

		// category skyplot
        PreferenceCategory prefCatSkyplot = 
        	addNewPreferenceCategory(activity, R.string.pref_gps_skyplot, preferenceGps);

        SettingItems.addPrefGpsAltitudeManualCorrection(activity, prefCatGlobal);
        //SettingItems.addPrefGpsBeepOnGpsFix(activity, prefCatGlobal);

        // disabling gps part
        SettingItems.addPrefGpsDisable(activity, prefCatDisable);
        SettingItems.addPrefGuidingGpsRequired(activity, prefCatDisable);
        
        SettingItems.addPrefGpsSkyplotMode(activity, prefCatSkyplot);
        return init(preferenceGps);
	}
	
	public static PreferenceScreen createPrefSensors(CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceSensors = prefManager.createPreferenceScreen(activity);
		preferenceSensors.setTitle(R.string.pref_sensors);
        PreferenceCategory prefCatOrient = 
        	addNewPreferenceCategory(activity, R.string.pref_orientation, preferenceSensors);
		PreferenceCategory prefCatOrientAdvanced = 
			addNewPreferenceCategory(activity, R.string.pref_advanced_settings, preferenceSensors);

        SettingItems.addPrefSensorsCompassHardware(activity, prefCatOrient);
        SettingItems.addPrefSensorsCompassAutoChange(activity, prefCatOrient);
        SettingItems.addPrefSensorsCompassAutoChangeValue(activity, prefCatOrient);
        SettingItems.addPrefSensorsBearingTrue(activity, prefCatOrient);
        SettingItems.addPrefSensorsOrienFilter(activity, prefCatOrient);
        
		SettingItems.addPrefSensorsOrienAngleModifierPortrait(activity, prefCatOrientAdvanced);
		SettingItems.addPrefSensorsOrienAngleModifierLandscape(activity, prefCatOrientAdvanced);

        return init(preferenceSensors);
	}
	
	public static PreferenceScreen createPrefGuiding(CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceGuiding = prefManager.createPreferenceScreen(activity);
		preferenceGuiding.setTitle(R.string.pref_guiding);
		PreferenceCategory prefCatGlobal = 
			addNewPreferenceCategory(activity, R.string.pref_global, preferenceGuiding);
		PreferenceCategory prefCatWptGuide = 
			addNewPreferenceCategory(activity, R.string.waypoints, preferenceGuiding);
		PreferenceCategory prefCatMap = 
			addNewPreferenceCategory(activity, R.string.pref_style_on_map, preferenceGuiding);

		SettingItems.addPrefGuidingCompassSounds(activity, prefCatGlobal);
		
		SettingItems.addPrefGuidingWptSound(activity, prefCatWptGuide);
		SettingItems.addPrefGuidingWptSoundDistance(activity, prefCatWptGuide);
		
		SettingItems.addPrefGuidingDrawDistance(activity, prefCatMap);
		SettingItems.addPrefGuidingDrawAzimuth(activity, prefCatMap);
		SettingItems.addPrefGuidingDrawColor(activity, prefCatMap);
		SettingItems.addPrefGuidingDrawFontSize(activity, prefCatMap);
        return init(preferenceGuiding);
	}
	
	public static PreferenceScreen createPrefLocale(CustomPreferenceActivity activity,
			PreferenceManager prefManager) {
		PreferenceScreen preferenceLocale = prefManager.createPreferenceScreen(activity);
		preferenceLocale.setTitle(R.string.pref_locale);
		PreferenceCategory prefCatLang = 
			addNewPreferenceCategory(activity, R.string.pref_language, preferenceLocale);
		PreferenceCategory prefCatLocale = 
			addNewPreferenceCategory(activity, R.string.pref_units, preferenceLocale);

		SettingItems.addPrefLocal(activity, prefCatLang);
		SettingItems.addPrefUnitsCooType(activity, prefCatLocale);
        SettingItems.addPrefUnitsCooLatLon(activity, prefCatLocale);
        SettingItems.addPrefUnitsLength(activity, prefCatLocale);
        SettingItems.addPrefUnitsAltitude(activity, prefCatLocale);
        SettingItems.addPrefUnitsSpeed(activity, prefCatLocale);
        SettingItems.addPrefUnitsAngle(activity, prefCatLocale);
        
        return init(preferenceLocale);
	}
}
