package menion.android.whereyougo.gui;

public interface Refreshable {
	
	public void refresh();
}
