package menion.android.whereyougo.gui;

import java.util.Vector;

import cz.matejcik.openwig.Engine;
import cz.matejcik.openwig.Task;

import menion.android.utils.Images;
import menion.android.whereyougo.Main;
import menion.android.whereyougo.R;
import menion.android.whereyougo.WUI;
import android.graphics.Bitmap;

public class ListTasks extends ListVarious {

	@Override
	protected void callStuff(Object what) {
		Task z = (Task) what;
		if (z.hasEvent("OnClick")) {
			Engine.callEvent(z, "OnClick", null);
		} else {
			Main.wui.showScreen(WUI.DETAILSCREEN, z);
		}
		ListTasks.this.finish();
	}

	@Override
	protected String getStuffName(Object what) {
		return ((Task) what).name;
	}

	@Override
	protected Vector<Object> getValidStuff() {
		Vector<Object> newtasks = new Vector<Object>();
		for (int i = 0; i < Engine.instance.cartridge.tasks.size(); i++) {
			Task t = (Task) Engine.instance.cartridge.tasks.get(i);
			if (t.isVisible())
				newtasks.add(t);
		}
		return newtasks;
	}

	@Override
	protected boolean stillValid() {
		return true;
	}
	
	private static Bitmap[] stateIcons;
	static {
		stateIcons = new Bitmap[3];
		stateIcons[Task.PENDING] = Images.getImageB(R.drawable.task_pending);
		stateIcons[Task.DONE] = Images.getImageB(R.drawable.task_done);
		stateIcons[Task.FAILED] = Images.getImageB(R.drawable.task_failed);
	}
	
	protected Bitmap getStuffIcon(Object what) {
		return stateIcons[((Task) what).state()];
	}
	
	// TODO in TAB version
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
//			return getParent().onKeyDown(keyCode, event);
//		} else {
//			return super.onKeyDown(keyCode, event);
//		}
//	}
}
