package menion.android.whereyougo.gui;

import menion.android.gui.extension.CustomActivity;
import menion.android.gui.location.SatellitesFragment;
import android.os.Bundle;
import android.widget.LinearLayout;

public class GpsActivity extends CustomActivity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LinearLayout llContent = new LinearLayout(this);
		llContent.setId(1);
		setContentView(llContent);
		
		getSupportFragmentManager().beginTransaction().add(1, new SatellitesFragment()).commit();
		
		
		// set title
//		((TextView) findViewById(R.id.title_text)).setText(R.string.satellites);
		
//        // set top panel buttons
//		View.OnClickListener mOnClickListener = new View.OnClickListener() {
//			public void onClick(final View v) {
//				if (v.getId() == R.id.btn_settings_gps) {
//					UtilsSettings.showSettings(GpsActivity.this, UtilsSettings.TYPE_ONLY_GPS);
//				} else if (v.getId() == R.id.btn_settings_sensors) {
//					UtilsSettings.showSettings(GpsActivity.this, UtilsSettings.TYPE_ONLY_SENSORS);
//				} else if (v.getId() == R.id.btn_settings_gps_system) {
//					startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
//				} else if (v.getId() == R.id.btn_home) {
//					Utils.callHome(GpsActivity.this);
//				}
//			}
//		};
//		View.OnLongClickListener mOnLongClickListener = new View.OnLongClickListener() {
//			public boolean onLongClick(View v) {
//				if (v.getId() == R.id.btn_settings_gps) {
//				} else if (v.getId() == R.id.btn_settings_sensors) {
//				} else if (v.getId() == R.id.btn_settings_gps_system) {
//				} else if (v.getId() == R.id.btn_home) {
//				}
//				return true;
//			}
//		};
//		UtilsGUI.setButtons(GpsActivity.this, new int[] {
//				R.id.btn_settings_gps, R.id.btn_settings_sensors, R.id.btn_settings_gps_system, R.id.btn_home
//			}, mOnClickListener, mOnLongClickListener);
	}
}
