package menion.android.whereyougo.gui;

import menion.android.gui.extension.CustomActivity;
import menion.android.guiding.GuidingFragment;
import android.os.Bundle;
import android.widget.LinearLayout;

public class GuideActivity extends CustomActivity {
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LinearLayout llContent = new LinearLayout(this);
		llContent.setId(1);
		setContentView(llContent);
		
		getSupportFragmentManager().beginTransaction().add(1, new GuidingFragment()).commit();
		
//		// set title
//		((TextView) findViewById(R.id.title_text)).setText(
//				(A.getGuidingContent().getTargetWaypoint() != null ?
//						A.getGuidingContent().getTargetWaypoint().getName() : getString(R.string.no_target)));
//		
//        // set geocaching button visibility
//        if (A.getGuidingContent().getTargetWaypoint() == null ||
//        		!A.getGuidingContent().getTargetWaypoint().hasGeocachingData()) {
//        	findViewById(R.id.btn_geocaching).setVisibility(View.GONE);
//        }
//        
//        // set top panel buttons
//		View.OnClickListener mOnClickListener = new View.OnClickListener() {
//			public void onClick(final View v) {
//				if (v.getId() == R.id.btn_geocaching) {
//					GeocachingScreen.wpt = A.getGuidingContent().getTargetWaypoint();
//					Intent intent = new Intent(GuideActivity.this, GeocachingScreen.class);
//					startActivity(intent);
//				} else if (v.getId() == R.id.btn_settings_guide) {
//					UtilsSettings.showSettings(GuideActivity.this, UtilsSettings.TYPE_ONLY_GUIDING);
//				} else if (v.getId() == R.id.btn_settings_sensors) {
//					UtilsSettings.showSettings(GuideActivity.this, UtilsSettings.TYPE_ONLY_SENSORS);
//				} else if (v.getId() == R.id.btn_home) {
//					Utils.callHome(GuideActivity.this);
//				}
//			}
//		};
//		View.OnLongClickListener mOnLongClickListener = new View.OnLongClickListener() {
//			public boolean onLongClick(View v) {
//				if (v.getId() == R.id.btn_geocaching) {
//				} else if (v.getId() == R.id.btn_settings_guide) {
//				} else if (v.getId() == R.id.btn_settings_sensors) {
//				} else if (v.getId() == R.id.btn_home) {
//				}
//				return true;
//			}
//		};
//		UtilsGUI.setButtons(this, new int[] {
//				R.id.btn_geocaching, R.id.btn_settings_guide,
//				R.id.btn_settings_sensors, R.id.btn_home
//			}, mOnClickListener, mOnLongClickListener);
	}
}
