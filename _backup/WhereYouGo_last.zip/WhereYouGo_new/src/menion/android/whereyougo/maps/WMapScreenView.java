package menion.android.whereyougo.maps;

import menion.android.geoData.GeoData;
import menion.android.geoData.UtilsGeoData;
import menion.android.geoData.Waypoint;
import menion.android.maps.MapScreenView;
import menion.android.maps.MapScreenViewHandler;
import menion.android.maps.mapItems.PointMapItem;
import menion.android.settings.Settings;
import menion.android.utils.A;
import menion.android.utils.Images;
import menion.android.utils.geometry.Point2D.Float;
import android.content.Context;
import android.graphics.Bitmap;
import android.location.Location;
import android.util.AttributeSet;
import cz.matejcik.openwig.Zone;

public class WMapScreenView extends MapScreenView {

	public static final String MAP_ITEM_TEMP_PLACE_NAME = "mapItemTempPlaceName";
	public static final String MAP_ITEM_TEMP_ZONE_NAME = "mapItemTempZoneName";
	
	public static void removeTempItems(boolean alsoNavigation) {
		int size = A.getMapItemManager().getItemCount();
		for (int i = 0; i < size; i++) {
			String itemName = A.getMapItemManager().getItemName(i);
			if (itemName == null || itemName.length() == 0)
				continue;

			if (itemName.startsWith(MAP_ITEM_TEMP_PLACE_NAME) ||
					itemName.startsWith(MAP_ITEM_TEMP_ZONE_NAME)) {
				A.getMapItemManager().removeItem(itemName);
			}
		}
		
		if (alsoNavigation)
			A.getGuidingContent().guideStop();
	}
	
	public static void addZonePoint(Waypoint wpt) {
		if (wpt == null)
			return;
		
		PointMapItem pmi = new PointMapItem(null);
		pmi.addWaypoint(wpt);
		A.getMapItemManager().addItem(MAP_ITEM_TEMP_PLACE_NAME + "_" + wpt.getName(), pmi);
	}
	
	public static void addZone(Zone z) {
		ZoneMapItem zmi = new ZoneMapItem(z);
		A.getMapItemManager().addItem(MAP_ITEM_TEMP_ZONE_NAME + "_" + z.name, zmi);
	}
	
	public WMapScreenView(Context context) {
		super(context);
		registerHandler(handler);
	}
	
    public WMapScreenView(Context context, AttributeSet attr) {
    	super(context, attr);
    	registerHandler(handler);
    }

    private MapScreenViewHandler handler = new MapScreenViewHandler() {

		@Override
		public Bitmap getGeoDataIcon(GeoData data) {
			if (data instanceof Waypoint) {
				Waypoint wpt = (Waypoint) data;
				Bitmap icon = Images.IMAGE_EMPTY_B;
				if (wpt.styleNormal != null)
					icon = wpt.styleNormal.getIcon();
				return icon;
			} else {
				return Images.IMAGE_EMPTY_B;
			}
		}

		@Override
		public void onMapTapLong(Float p1, Location loc, boolean mapCenter) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onMapTapDouble(Float p1, Location loc) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void doSelection(Float p, GeoData data) {
	    	if (data != null) {
	    		Bitmap icon = Images.IMAGE_EMPTY_B;
	    		if (data.styleNormal != null)
	    			icon = data.styleNormal.getIcon();
	    		
	    		UtilsGeoData.showInfoDialog(Settings.getCurrentActivity(), data, icon, null);
	    	}
		}

		@Override
		public void onDoubleTouch() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onTripleTouch() {
			// TODO Auto-generated method stub
			
		}
    	
    };
}
