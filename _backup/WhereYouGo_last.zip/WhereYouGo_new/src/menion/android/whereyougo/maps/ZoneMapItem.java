/****************************************************************************
 *
 * Copyright (C) 2009-2010 Menion. All rights reserved.
 *
 * This file is part of the LocA & SmartMaps software.
 *
 * Email menion@asamm.cz for more information.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
 * WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 ***************************************************************************/
package menion.android.whereyougo.maps;

import java.util.ArrayList;

import menion.android.geoData.GeoData;
import menion.android.geoData.Waypoint;
import menion.android.maps.background.MapScreenBackgroundTransform;
import menion.android.maps.mapItems.MapItem;
import menion.android.maps.mapItems.MapItemManager;
import menion.android.utils.A;
import menion.android.utils.geometry.Point2D;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.RectF;
import android.location.Location;
import cz.matejcik.openwig.Zone;

/**
 * Route on map
 * @author menion
 * @since 25.1.2010 2010
 */
public class ZoneMapItem extends MapItem {

	private static final String TAG = "ZoneMapItem";
	
	private Zone z;

    private Path pathBBox;
    private Path pathBorder;

    private static Paint paintTrack;
    private static Paint paintPoints;
    private static Paint paintDotHightlight;
    private static Paint paintAroundHightlight;
    static {
        paintTrack = new Paint();
        paintTrack.setStyle(Style.STROKE);
        paintTrack.setAntiAlias(true);
        paintTrack.setStrokeWidth(3.0f);
        paintTrack.setAlpha(150);
        
        paintPoints = new Paint();
        paintPoints.setStyle(Style.FILL);

        paintDotHightlight = new Paint();
        paintDotHightlight.setColor(Color.RED);
        paintDotHightlight.setStrokeWidth(2.0f);
    	paintDotHightlight.setStyle(Style.FILL);
    	
    	paintAroundHightlight = new Paint(paintDotHightlight);
    	paintAroundHightlight.setStyle(Style.STROKE);
    }

    private int colorBBox = Color.LTGRAY;
    private int colorBorder = Color.MAGENTA;
    
    /**
     * Constructor
     * @param points Location4D vector of points
     */
    public ZoneMapItem(Zone zone) {
        super();
        this.z = zone;
    }

    public void panItem(float moveX, float moveY) {
    	panItems(moveX, moveY);
   		pathBBox.offset(moveX, moveY);
   		pathBorder.offset(moveX, moveY);
    }
    
	private static Location createLocation(double lat, double lon) {
		Location loc = new Location(TAG);
		loc.setLatitude(lat);
		loc.setLongitude(lon);
		return loc;
	}

	@Override
	protected boolean initializeItem() {
		// prepare border data
		ArrayList<Location> locBorder = new ArrayList<Location>();
		for (int i = 0; i < z.points.length; i++) {
			Location loc = new Location(TAG);
			loc.setLatitude(z.points[i].latitude);
			loc.setLongitude(z.points[i].longitude);
			locBorder.add(loc);
		}
		if (z.points.length > 0) {
			Location loc = new Location(TAG);
			loc.setLatitude(z.points[0].latitude);
			loc.setLongitude(z.points[0].longitude);
			locBorder.add(loc);
		}

		int sizeBor  = locBorder.size();
		if (sizeBor == 0)
			return false;

		// prepare BBox data
		ArrayList<Location> locBBox = new ArrayList<Location>();
		locBBox.add(createLocation(z.bbTop, z.bbLeft));
		locBBox.add(createLocation(z.bbTop, z.bbRight));
		locBBox.add(createLocation(z.bbBottom, z.bbRight));
		locBBox.add(createLocation(z.bbBottom, z.bbLeft));
		locBBox.add(createLocation(z.bbTop, z.bbLeft));
		
		int sizeBBox = locBBox.size();
		if (sizeBBox == 0)
			return false;
		
		final ArrayList<Location> locs = new ArrayList<Location>();
		for (Location loc : locBorder) {
			locs.add(loc);
		}
		for (Location loc : locBBox) {
			locs.add(loc);
		}
		
    	initializeItems(new ItemInitialized() {
			@Override
			public int getSize() {
				return locs.size();
			}
			
			@Override
			public Location getLocation(int i) {
				return locs.get(i);
			}
		}, 0, locs.size() - 1, 0);
    
		pathBorder = new Path();
		pathBorder.moveTo((float) itemsX[0], (float) itemsY[0]);
		for (int i = 1; i < sizeBor; i++) {
			pathBorder.lineTo((float) itemsX[i], (float) itemsY[i]);
		}

		
		pathBBox = new Path();
		pathBBox.moveTo((float) itemsX[sizeBor], (float)  itemsY[sizeBor]);
		for (int i = 1; i < sizeBBox; i++) {
			pathBBox.lineTo((float) itemsX[sizeBor + i], (float) itemsY[sizeBor + i]);
		}
		return true;
	}

	@Override
	protected void drawItemOnTerrain(Canvas c, int canvasWidth, int canvasHeight) {
    	if (pathBorder != null) {
            // DRAW BBOX AND BORDER
            paintTrack.setColor(colorBBox);
            c.drawPath(pathBBox, paintTrack);
            paintTrack.setColor(colorBorder);
            c.drawPath(pathBorder, paintTrack);
            
            // DRAW ACTUAL NEAREST
    		Location loc = new Location(TAG);
    		loc.setLatitude(z.nearestPoint.latitude);
    		loc.setLongitude(z.nearestPoint.longitude);
    		Point2D.Float point = A.getMapContent().getActualMapLayer().convertGeoToScreen(loc);
    		Waypoint wpt = new Waypoint(TAG);
    		wpt.setLocation(loc, true);
    		wpt.setName("Nearest");
    		wpt.paint(c, point.x, point.y, MapItemManager.getPixelsPerMeter(), null, null);
        }
    }

	@Override
	protected void drawItemPlastic(Canvas c, MapScreenBackgroundTransform mapTransform) {}

	@Override
	protected void getItemsAtRect(ArrayList<GeoData> geoData, RectF tapRect) {
//		if (locBBox.size() == itemsBBox.length && itemsBBox.length == 5) {
//			RectF bbBox = new RectF(itemsBBox[0].x, itemsBBox[0].y, itemsBBox[2].x, itemsBBox[2].y);
//			
//			if (RectF.intersects(bbBox, tapRect)) {
//				Waypoint wpt = new Waypoint(z.name);
//				wpt.addParameter(z.description, GeoDataExtra.PAR_DESCRIPTION);
//				Location loc = new Location(TAG);
//				loc.setLatitude(z.nearestPoint.latitude);
//				loc.setLongitude(z.nearestPoint.longitude);
//				wpt.setLocation(loc, true);
//				geoData.add(wpt);
//            }
//        }
		return;
	}
}
